///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// */
//

package main;

import java.util.Scanner;
import service.ServiceProperti;

/**
 * 
 */
public class AlatOlahraga {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ServiceProperti service = new ServiceProperti();
        int pilihan;

        do {
            System.out.println("\n=== MENU ALAT OLAHRAGA ===");
            System.out.println("1. Tambah Properti");
            System.out.println("2. Tampilkan Properti");
            System.out.println("3. Update Properti");
            System.out.println("4. Hapus Properti");
            System.out.println("5. Cari Properti");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");

            while (!sc.hasNextInt()) {
                System.out.println(" Harus angka!");
                sc.next();
                System.out.print("Pilih menu: ");
            }
            pilihan = sc.nextInt();
            sc.nextLine(); // buang enter

            switch (pilihan) {
                case 1 -> service.tambahProperti();
                case 2 -> service.tampilkanProperti();
                case 3 -> service.updateProperti();
                case 4 -> service.hapusProperti();
                case 5 -> service.cariProperti();
                case 0 -> System.out.println("Keluar dari program.");
                default -> System.out.println("Menu tidak ada!");
            }
        } while (pilihan != 0);

        sc.close();
    }
}