/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import model.Properti;

/**
 * Class ServiceProperti sebagai SERVICE
 * Berisi logika CRUD (Create, Read, Update, Delete) dan Search.
 */
public class ServiceProperti {
    private final ArrayList<Properti> list = new ArrayList<>();
    private final Scanner sc = new Scanner(System.in);

    // CREATE
    public void tambahProperti() {
        System.out.print("ID : ");
        String id = sc.nextLine().trim();

        // Validasi ID unik
        for (Properti p : list) {
            if (p.getId().equalsIgnoreCase(id)) {
                System.out.println("ID sudah ada!");
                return;
            }
        }

        System.out.print("Nama : ");
        String nama = sc.nextLine();

        int jumlah;
        while (true) {
            System.out.print("Jumlah : ");
            if (sc.hasNextInt()) {
                jumlah = sc.nextInt();
                sc.nextLine();
                break;
            } else {
                System.out.println("Harus angka!");
                sc.next();
            }
        }

        list.add(new Properti(id, nama, jumlah));
        System.out.println("Data berhasil ditambah!");
    }

    // READ
    public void tampilkanProperti() {
        if (list.isEmpty()) {
            System.out.println("Data masih kosong.");
            return;
        }
        for (Properti p : list) {
            System.out.println(p);
        }
    }

    // UPDATE
    public void updateProperti() {
        System.out.print("Masukkan ID yang mau diupdate: ");
        String id = sc.nextLine();
        for (Properti p : list) {
            if (p.getId().equalsIgnoreCase(id)) {
                System.out.print("Nama baru : ");
                p.setNama(sc.nextLine());

                int jumlah;
                while (true) {
                    System.out.print("Jumlah baru : ");
                    if (sc.hasNextInt()) {
                        jumlah = sc.nextInt();
                        sc.nextLine();
                        p.setJumlah(jumlah);
                        break;
                    } else {
                        System.out.println("Harus angka!");
                        sc.next();
                    }
                }

                System.out.println("Data berhasil diupdate!");
                return;
            }
        }
        System.out.println("ID tidak ditemukan!");
    }

    // DELETE
    public void hapusProperti() {
        System.out.print("Masukkan ID yang mau dihapus: ");
        String id = sc.nextLine();

        Iterator<Properti> it = list.iterator();
        while (it.hasNext()) {
            Properti p = it.next();
            if (p.getId().equalsIgnoreCase(id)) {
                it.remove();
                System.out.println("Data dihapus!");
                return;
            }
        }
        System.out.println("ID tidak ditemukan!");
    }

    // SEARCH
    public void cariProperti() {
        System.out.print("Masukkan kata kunci: ");
        String key = sc.nextLine().toLowerCase();
        boolean ketemu = false;
        for (Properti p : list) {
            if (p.getId().toLowerCase().contains(key) || p.getNama().toLowerCase().contains(key)) {
                System.out.println(p);
                ketemu = true;
            }
        }
        if (!ketemu) System.out.println("Tidak ada data yang cocok.");
    }
}
